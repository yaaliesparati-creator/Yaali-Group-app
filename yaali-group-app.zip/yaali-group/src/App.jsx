import { useState, useEffect } from "react";

// ─── DESIGN TOKENS ───────────────────────────────────────────────
const C = {
  teal:    "#1A6B6B",
  tealDk:  "#0F4444",
  tealLt:  "#2A8A8A",
  gold:    "#C9A84C",
  goldLt:  "#E8C96A",
  white:   "#FFFFFF",
  offWht:  "#F7F9F8",
  gray50:  "#F0F4F3",
  gray100: "#D8E3E3",
  gray400: "#7A9696",
  gray700: "#2C3E3E",
  red:     "#C0392B",
};

const BUSINESSES = ["inmobiliaria", "studio", "hyg"];

const BIZ_META = {
  inmobiliaria: { label: "Yaali Inmobiliaria", icon: "🏠", color: C.teal,    desc: "Compra, venta y renta de inmuebles" },
  studio:       { label: "Yaali Studio",       icon: "🎨", color: C.tealDk,  desc: "Marketing & Diseño" },
  hyg:          { label: "HYG Asesorías",      icon: "📋", color: C.gold,    desc: "Asesorías Mejoravit" },
};

// ─── STORAGE HELPERS ──────────────────────────────────────────────
async function load(key, fallback) {
  try {
    const r = await window.storage.get(key);
    return r ? JSON.parse(r.value) : fallback;
  } catch { return fallback; }
}
async function save(key, val) {
  try { await window.storage.set(key, JSON.stringify(val)); } catch {}
}

// ─── INITIAL SEED DATA ────────────────────────────────────────────
const seedClientes = {
  inmobiliaria: [
    { id: 1, nombre: "María González", tel: "8112345678", email: "maria@email.com", notas: "Busca casa 3 recámaras INFONAVIT", fecha: "2025-06-01", status: "Activo" },
    { id: 2, nombre: "Carlos Ramírez", tel: "8198765432", email: "carlos@email.com", notas: "Interesado en terreno comercial", fecha: "2025-06-05", status: "Prospecto" },
  ],
  studio: [
    { id: 1, nombre: "Ferretería Ramos", tel: "8113334455", email: "ramos@negocio.com", notas: "Campaña redes sociales", fecha: "2025-05-20", status: "Activo" },
  ],
  hyg: [
    { id: 1, nombre: "Juan Pérez", tel: "8119876543", email: "juan@email.com", notas: "Mejoravit baño y cocina", fecha: "2025-06-03", status: "En proceso" },
  ],
};
const seedServicios = {
  inmobiliaria: [
    { id: 1, nombre: "Asesoría de compra", precio: 5000, descripcion: "Acompañamiento en proceso de compra con crédito INFONAVIT/FOVISSSTE/Bancario", activo: true },
    { id: 2, nombre: "Listado de propiedad", precio: 2500, descripcion: "Publicación y gestión de venta/renta", activo: true },
  ],
  studio: [
    { id: 1, nombre: "Identidad de marca", precio: 8000, descripcion: "Logo, paleta, tipografía, manual de uso", activo: true },
    { id: 2, nombre: "Gestión de redes", precio: 3500, descripcion: "Contenido mensual para Instagram y Facebook", activo: true },
    { id: 3, nombre: "Diseño de flyer", precio: 800, descripcion: "Flyer digital o impreso con diseño profesional", activo: true },
  ],
  hyg: [
    { id: 1, nombre: "Asesoría Mejoravit", precio: 1500, descripcion: "Gestoría completa para crédito de mejora de vivienda", activo: true },
    { id: 2, nombre: "Valuación de mejoras", precio: 800, descripcion: "Evaluación de obra para autorización de crédito", activo: true },
  ],
};
const seedInventario = [
  { id: 1, titulo: "Casa en Cumbres", tipo: "Casa", operacion: "Venta", precio: 1850000, direccion: "Cumbres 4to Sector, Monterrey", recamaras: 3, banos: 2, m2: 120, credito: ["INFONAVIT","FOVISSSTE","Bancario"], status: "Disponible", notas: "Con jardín y 2 estacionamientos" },
  { id: 2, titulo: "Departamento Valle Oriente", tipo: "Departamento", operacion: "Renta", precio: 12000, direccion: "Valle Oriente, San Pedro", recamaras: 2, banos: 2, m2: 85, credito: [], status: "Disponible", notas: "Amueblado, piso 5" },
  { id: 3, titulo: "Terreno Industrial Apodaca", tipo: "Terreno", operacion: "Venta", precio: 3200000, direccion: "Parque Industrial Apodaca", recamaras: 0, banos: 0, m2: 500, credito: ["Bancario"], status: "Apartado", notas: "Uso de suelo industrial" },
];

// ─── UTILS ────────────────────────────────────────────────────────
const fmt = (n) => n?.toLocaleString("es-MX", { style: "currency", currency: "MXN", maximumFractionDigits: 0 });
const newId = (arr) => (arr.length ? Math.max(...arr.map(x => x.id)) + 1 : 1);

// ─── SMALL COMPONENTS ─────────────────────────────────────────────
const Badge = ({ text, color = C.teal }) => (
  <span style={{ background: color + "22", color, border: `1px solid ${color}44`, borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" }}>{text}</span>
);

const Btn = ({ children, onClick, variant = "primary", small, disabled, style: sx = {} }) => {
  const base = { border: "none", borderRadius: 8, cursor: disabled ? "not-allowed" : "pointer", fontWeight: 700, fontFamily: "inherit", transition: "all .15s", opacity: disabled ? .5 : 1, ...sx };
  const variants = {
    primary: { background: `linear-gradient(135deg,${C.teal},${C.tealDk})`, color: C.white, padding: small ? "6px 14px" : "10px 22px", fontSize: small ? 12 : 14 },
    gold: { background: `linear-gradient(135deg,${C.gold},${C.goldLt})`, color: C.tealDk, padding: small ? "6px 14px" : "10px 22px", fontSize: small ? 12 : 14 },
    ghost: { background: "transparent", color: C.teal, padding: small ? "5px 12px" : "9px 20px", fontSize: small ? 12 : 14, border: `1.5px solid ${C.teal}` },
    danger: { background: "#fee2e2", color: C.red, padding: small ? "5px 12px" : "9px 20px", fontSize: small ? 12 : 14, border: `1.5px solid #fca5a5` },
  };
  return <button onClick={disabled ? undefined : onClick} style={{ ...base, ...variants[variant] }}>{children}</button>;
};

const Input = ({ label, value, onChange, type = "text", placeholder, required, options, rows }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
    {label && <label style={{ fontSize: 12, fontWeight: 700, color: C.gray700, textTransform: "uppercase", letterSpacing: .5 }}>{label}{required && <span style={{ color: C.red }}> *</span>}</label>}
    {options ? (
      <select value={value} onChange={e => onChange(e.target.value)} style={inputSt}>
        {options.map(o => <option key={o}>{o}</option>)}
      </select>
    ) : rows ? (
      <textarea rows={rows} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={{ ...inputSt, resize: "vertical" }} />
    ) : (
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={inputSt} />
    )}
  </div>
);
const inputSt = { border: `1.5px solid ${C.gray100}`, borderRadius: 8, padding: "9px 12px", fontSize: 14, color: C.gray700, fontFamily: "inherit", outline: "none", background: C.white };

const Card = ({ children, style: sx = {} }) => (
  <div style={{ background: C.white, borderRadius: 12, boxShadow: "0 1px 8px rgba(0,0,0,.07)", padding: 16, ...sx }}>{children}</div>
);

const Modal = ({ title, onClose, children }) => (
  <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.45)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
    <div style={{ background: C.white, borderRadius: 16, width: "100%", maxWidth: 480, maxHeight: "90vh", overflow: "auto", boxShadow: "0 20px 60px rgba(0,0,0,.25)" }}>
      <div style={{ padding: "16px 20px", borderBottom: `1px solid ${C.gray100}`, display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: C.white, zIndex: 1 }}>
        <span style={{ fontWeight: 800, fontSize: 16, color: C.tealDk }}>{title}</span>
        <button onClick={onClose} style={{ background: C.gray50, border: "none", borderRadius: "50%", width: 30, height: 30, cursor: "pointer", fontSize: 16, color: C.gray400 }}>×</button>
      </div>
      <div style={{ padding: 20 }}>{children}</div>
    </div>
  </div>
);

const Toast = ({ msg }) => msg ? (
  <div style={{ position: "fixed", bottom: 80, left: "50%", transform: "translateX(-50%)", background: C.tealDk, color: C.white, padding: "10px 24px", borderRadius: 24, fontSize: 13, fontWeight: 600, zIndex: 2000, boxShadow: "0 4px 20px rgba(0,0,0,.3)", whiteSpace: "nowrap" }}>{msg}</div>
) : null;

// ─── STATUS OPTIONS ───────────────────────────────────────────────
const STATUS_CLIENTE = ["Prospecto", "Activo", "Cerrado", "Inactivo"];
const STATUS_INMO = ["Disponible", "Apartado", "Vendido", "Rentado"];
const TIPOS_INMO = ["Casa", "Departamento", "Terreno", "Local Comercial", "Oficina"];
const OPS_INMO = ["Venta", "Renta", "Venta y Renta"];
const CREDITOS = ["INFONAVIT", "FOVISSSTE", "Bancario", "Contado"];

// ═══════════════════════════════════════════════════════════════════
// CLIENTES MODULE
// ═══════════════════════════════════════════════════════════════════
function ClientesModule({ biz, clientes, onChange, toast }) {
  const [modal, setModal] = useState(null); // null | "new" | {id}
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ nombre: "", tel: "", email: "", notas: "", fecha: new Date().toISOString().slice(0, 10), status: "Prospecto" });

  const filtered = clientes.filter(c => c.nombre.toLowerCase().includes(search.toLowerCase()) || c.tel?.includes(search));

  const openNew = () => { setForm({ nombre: "", tel: "", email: "", notas: "", fecha: new Date().toISOString().slice(0, 10), status: "Prospecto" }); setModal("new"); };
  const openEdit = (c) => { setForm({ ...c }); setModal(c.id); };

  const save = () => {
    if (!form.nombre.trim()) return;
    let updated;
    if (modal === "new") updated = [...clientes, { ...form, id: newId(clientes) }];
    else updated = clientes.map(c => c.id === modal ? { ...form, id: modal } : c);
    onChange(updated); setModal(null); toast(modal === "new" ? "Cliente agregado ✓" : "Cliente actualizado ✓");
  };

  const del = (id) => { onChange(clientes.filter(c => c.id !== id)); toast("Cliente eliminado"); };

  const statusColor = { Activo: C.teal, Prospecto: C.gold, Cerrado: C.gray400, Inactivo: "#e74c3c" };

  return (
    <div>
      <div style={{ display: "flex", gap: 10, marginBottom: 14, alignItems: "center" }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar cliente..." style={{ ...inputSt, flex: 1 }} />
        <Btn onClick={openNew} variant="gold" small>+ Agregar</Btn>
      </div>

      {filtered.length === 0 && <div style={{ textAlign: "center", color: C.gray400, padding: 40 }}>No hay clientes aún.<br /><span style={{ fontSize: 12 }}>Agrega el primero con el botón +</span></div>}

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {filtered.map(c => (
          <Card key={c.id} style={{ padding: "12px 16px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 800, fontSize: 15, color: C.tealDk, marginBottom: 2 }}>{c.nombre}</div>
                <div style={{ fontSize: 13, color: C.gray400 }}>{c.tel} {c.email ? `· ${c.email}` : ""}</div>
                {c.notas && <div style={{ fontSize: 12, color: C.gray700, marginTop: 4, background: C.gray50, borderRadius: 6, padding: "4px 8px" }}>{c.notas}</div>}
                <div style={{ marginTop: 6, display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                  <Badge text={c.status} color={statusColor[c.status] || C.gray400} />
                  <span style={{ fontSize: 11, color: C.gray400 }}>{c.fecha}</span>
                </div>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <Btn onClick={() => openEdit(c)} variant="ghost" small>✏️</Btn>
                <Btn onClick={() => del(c.id)} variant="danger" small>🗑</Btn>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {modal && (
        <Modal title={modal === "new" ? "Nuevo Cliente" : "Editar Cliente"} onClose={() => setModal(null)}>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <Input label="Nombre completo" required value={form.nombre} onChange={v => setForm({ ...form, nombre: v })} placeholder="Ej. María González" />
            <Input label="Teléfono" value={form.tel} onChange={v => setForm({ ...form, tel: v })} placeholder="81XXXXXXXX" type="tel" />
            <Input label="Email" value={form.email} onChange={v => setForm({ ...form, email: v })} placeholder="correo@ejemplo.com" type="email" />
            <Input label="Fecha" value={form.fecha} onChange={v => setForm({ ...form, fecha: v })} type="date" />
            <Input label="Status" value={form.status} onChange={v => setForm({ ...form, status: v })} options={STATUS_CLIENTE} />
            <Input label="Notas" value={form.notas} onChange={v => setForm({ ...form, notas: v })} placeholder="Observaciones sobre el cliente..." rows={3} />
            <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
              <Btn onClick={save} variant="primary" style={{ flex: 1 }} disabled={!form.nombre.trim()}>Guardar</Btn>
              <Btn onClick={() => setModal(null)} variant="ghost">Cancelar</Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SERVICIOS MODULE
// ═══════════════════════════════════════════════════════════════════
function ServiciosModule({ biz, servicios, onChange, toast }) {
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({ nombre: "", precio: "", descripcion: "", activo: true });

  const openNew = () => { setForm({ nombre: "", precio: "", descripcion: "", activo: true }); setModal("new"); };
  const openEdit = (s) => { setForm({ ...s, precio: String(s.precio) }); setModal(s.id); };

  const save = () => {
    if (!form.nombre.trim()) return;
    const entry = { ...form, precio: Number(form.precio) || 0 };
    let updated;
    if (modal === "new") updated = [...servicios, { ...entry, id: newId(servicios) }];
    else updated = servicios.map(s => s.id === modal ? { ...entry, id: modal } : s);
    onChange(updated); setModal(null); toast("Servicio guardado ✓");
  };

  const del = (id) => { onChange(servicios.filter(s => s.id !== id)); toast("Servicio eliminado"); };
  const toggle = (id) => { onChange(servicios.map(s => s.id === id ? { ...s, activo: !s.activo } : s)); };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 14 }}>
        <Btn onClick={openNew} variant="gold" small>+ Agregar servicio</Btn>
      </div>

      {servicios.length === 0 && <div style={{ textAlign: "center", color: C.gray400, padding: 40 }}>Sin servicios registrados.</div>}

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {servicios.map(s => (
          <Card key={s.id} style={{ padding: "12px 16px", opacity: s.activo ? 1 : .6 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 800, fontSize: 15, color: C.tealDk }}>{s.nombre}</div>
                <div style={{ fontSize: 13, color: C.gold, fontWeight: 700, marginTop: 2 }}>{fmt(s.precio)}</div>
                {s.descripcion && <div style={{ fontSize: 12, color: C.gray700, marginTop: 4 }}>{s.descripcion}</div>}
                <div style={{ marginTop: 6 }}><Badge text={s.activo ? "Activo" : "Inactivo"} color={s.activo ? C.teal : C.gray400} /></div>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <Btn onClick={() => toggle(s.id)} variant="ghost" small>{s.activo ? "⏸" : "▶"}</Btn>
                <Btn onClick={() => openEdit(s)} variant="ghost" small>✏️</Btn>
                <Btn onClick={() => del(s.id)} variant="danger" small>🗑</Btn>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {modal && (
        <Modal title={modal === "new" ? "Nuevo Servicio" : "Editar Servicio"} onClose={() => setModal(null)}>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <Input label="Nombre del servicio" required value={form.nombre} onChange={v => setForm({ ...form, nombre: v })} placeholder="Ej. Diseño de logo" />
            <Input label="Precio (MXN)" value={form.precio} onChange={v => setForm({ ...form, precio: v })} placeholder="0" type="number" />
            <Input label="Descripción" value={form.descripcion} onChange={v => setForm({ ...form, descripcion: v })} rows={3} placeholder="Qué incluye este servicio..." />
            <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
              <Btn onClick={save} variant="primary" style={{ flex: 1 }} disabled={!form.nombre.trim()}>Guardar</Btn>
              <Btn onClick={() => setModal(null)} variant="ghost">Cancelar</Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// INVENTARIO MODULE (Inmobiliaria only)
// ═══════════════════════════════════════════════════════════════════
function InventarioModule({ inventario, onChange, toast }) {
  const [modal, setModal] = useState(null);
  const [filter, setFilter] = useState("Todos");
  const [search, setSearch] = useState("");
  const emptyForm = { titulo: "", tipo: "Casa", operacion: "Venta", precio: "", direccion: "", recamaras: "", banos: "", m2: "", credito: [], status: "Disponible", notas: "" };
  const [form, setForm] = useState(emptyForm);

  const filtered = inventario.filter(p => {
    const matchFilter = filter === "Todos" || p.status === filter || p.operacion === filter;
    const matchSearch = p.titulo?.toLowerCase().includes(search.toLowerCase()) || p.direccion?.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const openNew = () => { setForm(emptyForm); setModal("new"); };
  const openEdit = (p) => { setForm({ ...p, precio: String(p.precio), recamaras: String(p.recamaras), banos: String(p.banos), m2: String(p.m2) }); setModal(p.id); };

  const save = () => {
    if (!form.titulo.trim()) return;
    const entry = { ...form, precio: Number(form.precio) || 0, recamaras: Number(form.recamaras) || 0, banos: Number(form.banos) || 0, m2: Number(form.m2) || 0 };
    let updated;
    if (modal === "new") updated = [...inventario, { ...entry, id: newId(inventario) }];
    else updated = inventario.map(p => p.id === modal ? { ...entry, id: modal } : p);
    onChange(updated); setModal(null); toast("Propiedad guardada ✓");
  };

  const del = (id) => { onChange(inventario.filter(p => p.id !== id)); toast("Propiedad eliminada"); };

  const toggleCredito = (cr) => {
    const list = form.credito || [];
    setForm({ ...form, credito: list.includes(cr) ? list.filter(x => x !== cr) : [...list, cr] });
  };

  const statusColor = { Disponible: C.teal, Apartado: C.gold, Vendido: C.gray400, Rentado: "#8e44ad" };
  const FILTERS = ["Todos", "Disponible", "Venta", "Renta", "Apartado", "Vendido"];

  return (
    <div>
      <div style={{ display: "flex", gap: 10, marginBottom: 10, alignItems: "center" }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar propiedad..." style={{ ...inputSt, flex: 1 }} />
        <Btn onClick={openNew} variant="gold" small>+ Agregar</Btn>
      </div>

      <div style={{ display: "flex", gap: 6, marginBottom: 14, overflowX: "auto", paddingBottom: 4 }}>
        {FILTERS.map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{ border: "none", borderRadius: 20, padding: "5px 12px", fontSize: 12, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap", background: filter === f ? C.teal : C.gray50, color: filter === f ? C.white : C.gray400 }}>{f}</button>
        ))}
      </div>

      <div style={{ fontSize: 12, color: C.gray400, marginBottom: 10 }}>{filtered.length} propiedades</div>

      {filtered.length === 0 && <div style={{ textAlign: "center", color: C.gray400, padding: 40 }}>Sin propiedades en inventario.</div>}

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {filtered.map(p => (
          <Card key={p.id} style={{ padding: "14px 16px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 4, flexWrap: "wrap" }}>
                  <span style={{ fontWeight: 800, fontSize: 15, color: C.tealDk }}>{p.titulo}</span>
                  <Badge text={p.status} color={statusColor[p.status] || C.teal} />
                  <Badge text={p.operacion} color={C.tealLt} />
                </div>
                <div style={{ fontSize: 20, fontWeight: 900, color: C.gold, marginBottom: 4 }}>{fmt(p.precio)}{p.operacion === "Renta" ? "/mes" : ""}</div>
                <div style={{ fontSize: 12, color: C.gray400, marginBottom: 6 }}>📍 {p.direccion}</div>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap", fontSize: 12, color: C.gray700, marginBottom: 6 }}>
                  {p.tipo && <span>🏷 {p.tipo}</span>}
                  {p.recamaras > 0 && <span>🛏 {p.recamaras} rec.</span>}
                  {p.banos > 0 && <span>🚿 {p.banos} baños</span>}
                  {p.m2 > 0 && <span>📐 {p.m2} m²</span>}
                </div>
                {p.credito?.length > 0 && (
                  <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                    {p.credito.map(cr => <Badge key={cr} text={cr} color={C.tealDk} />)}
                  </div>
                )}
                {p.notas && <div style={{ fontSize: 11, color: C.gray400, marginTop: 6 }}>{p.notas}</div>}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6, marginLeft: 8 }}>
                <Btn onClick={() => openEdit(p)} variant="ghost" small>✏️</Btn>
                <Btn onClick={() => del(p.id)} variant="danger" small>🗑</Btn>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {modal && (
        <Modal title={modal === "new" ? "Nueva Propiedad" : "Editar Propiedad"} onClose={() => setModal(null)}>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <Input label="Título" required value={form.titulo} onChange={v => setForm({ ...form, titulo: v })} placeholder="Ej. Casa en Cumbres" />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <Input label="Tipo" value={form.tipo} onChange={v => setForm({ ...form, tipo: v })} options={TIPOS_INMO} />
              <Input label="Operación" value={form.operacion} onChange={v => setForm({ ...form, operacion: v })} options={OPS_INMO} />
            </div>
            <Input label="Precio (MXN)" value={form.precio} onChange={v => setForm({ ...form, precio: v })} placeholder="0" type="number" />
            <Input label="Dirección" value={form.direccion} onChange={v => setForm({ ...form, direccion: v })} placeholder="Colonia, Ciudad" />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
              <Input label="Recámaras" value={form.recamaras} onChange={v => setForm({ ...form, recamaras: v })} type="number" />
              <Input label="Baños" value={form.banos} onChange={v => setForm({ ...form, banos: v })} type="number" />
              <Input label="m²" value={form.m2} onChange={v => setForm({ ...form, m2: v })} type="number" />
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 700, color: C.gray700, textTransform: "uppercase", letterSpacing: .5, display: "block", marginBottom: 6 }}>Crédito aceptado</label>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {CREDITOS.map(cr => (
                  <button key={cr} onClick={() => toggleCredito(cr)} style={{ border: `1.5px solid ${form.credito?.includes(cr) ? C.teal : C.gray100}`, borderRadius: 20, padding: "5px 12px", fontSize: 12, fontWeight: 700, cursor: "pointer", background: form.credito?.includes(cr) ? C.teal + "22" : C.white, color: form.credito?.includes(cr) ? C.teal : C.gray400 }}>{cr}</button>
                ))}
              </div>
            </div>
            <Input label="Status" value={form.status} onChange={v => setForm({ ...form, status: v })} options={STATUS_INMO} />
            <Input label="Notas" value={form.notas} onChange={v => setForm({ ...form, notas: v })} rows={2} placeholder="Características adicionales..." />
            <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
              <Btn onClick={save} variant="primary" style={{ flex: 1 }} disabled={!form.titulo.trim()}>Guardar</Btn>
              <Btn onClick={() => setModal(null)} variant="ghost">Cancelar</Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════════════════════════
function Dashboard({ data }) {
  const stats = BUSINESSES.map(biz => ({
    ...BIZ_META[biz],
    biz,
    clientes: data.clientes[biz]?.length || 0,
    activos: data.clientes[biz]?.filter(c => c.status === "Activo").length || 0,
    servicios: data.servicios[biz]?.filter(s => s.activo).length || 0,
  }));

  const inmoTotal = data.inventario?.length || 0;
  const inmoDisp = data.inventario?.filter(p => p.status === "Disponible").length || 0;
  const inmoVal = data.inventario?.filter(p => p.status === "Disponible" && p.operacion === "Venta").reduce((a, p) => a + (p.precio || 0), 0) || 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Hero */}
      <div style={{ background: `linear-gradient(135deg,${C.tealDk},${C.teal})`, borderRadius: 16, padding: "24px 20px", color: C.white, position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", right: -20, top: -20, width: 120, height: 120, borderRadius: "50%", background: C.gold + "22" }} />
        <div style={{ position: "absolute", right: 20, bottom: -30, width: 80, height: 80, borderRadius: "50%", background: C.white + "11" }} />
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, opacity: .7, marginBottom: 4 }}>YAALI GROUP</div>
        <div style={{ fontSize: 26, fontWeight: 900, marginBottom: 2 }}>Panel General</div>
        <div style={{ fontSize: 13, opacity: .8 }}>• Encuentra Tu Lugar •</div>
      </div>

      {/* Stats cards */}
      {stats.map(s => (
        <Card key={s.biz} style={{ borderLeft: `4px solid ${s.color}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: C.gray400, textTransform: "uppercase", letterSpacing: 1 }}>{s.icon} {s.label}</div>
              <div style={{ fontSize: 12, color: C.gray400 }}>{s.desc}</div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
            {[
              { label: "Clientes", val: s.clientes },
              { label: "Activos", val: s.activos },
              { label: "Servicios", val: s.servicios },
            ].map(x => (
              <div key={x.label} style={{ background: C.gray50, borderRadius: 8, padding: "8px 10px", textAlign: "center" }}>
                <div style={{ fontSize: 22, fontWeight: 900, color: s.color }}>{x.val}</div>
                <div style={{ fontSize: 11, color: C.gray400 }}>{x.label}</div>
              </div>
            ))}
          </div>
          {s.biz === "inmobiliaria" && (
            <div style={{ marginTop: 10, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
              {[
                { label: "Inventario", val: inmoTotal },
                { label: "Disponibles", val: inmoDisp },
                { label: "Valor venta", val: inmoVal > 0 ? (inmoVal / 1000000).toFixed(1) + "M" : "0" },
              ].map(x => (
                <div key={x.label} style={{ background: C.gold + "15", borderRadius: 8, padding: "8px 10px", textAlign: "center" }}>
                  <div style={{ fontSize: 18, fontWeight: 900, color: C.gold }}>{x.val}</div>
                  <div style={{ fontSize: 11, color: C.gray400 }}>{x.label}</div>
                </div>
              ))}
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════════════
export default function App() {
  const [ready, setReady] = useState(false);
  const [nav, setNav] = useState("dashboard"); // dashboard | inmobiliaria | studio | hyg
  const [tab, setTab] = useState("clientes"); // clientes | servicios | inventario
  const [data, setData] = useState({ clientes: {}, servicios: {}, inventario: [] });
  const [toastMsg, setToastMsg] = useState("");

  // Load all data on mount
  useEffect(() => {
    (async () => {
      const clientes = {};
      const servicios = {};
      for (const biz of BUSINESSES) {
        clientes[biz] = await load(`yaali_clientes_${biz}`, seedClientes[biz]);
        servicios[biz] = await load(`yaali_servicios_${biz}`, seedServicios[biz]);
      }
      const inventario = await load("yaali_inventario", seedInventario);
      setData({ clientes, servicios, inventario });
      setReady(true);
    })();
  }, []);

  const toast = (msg) => { setToastMsg(msg); setTimeout(() => setToastMsg(""), 2500); };

  const updateClientes = async (biz, list) => {
    const next = { ...data, clientes: { ...data.clientes, [biz]: list } };
    setData(next); await save(`yaali_clientes_${biz}`, list);
  };
  const updateServicios = async (biz, list) => {
    const next = { ...data, servicios: { ...data.servicios, [biz]: list } };
    setData(next); await save(`yaali_servicios_${biz}`, list);
  };
  const updateInventario = async (list) => {
    setData({ ...data, inventario: list }); await save("yaali_inventario", list);
  };

  if (!ready) return (
    <div style={{ minHeight: "100vh", background: `linear-gradient(135deg,${C.tealDk},${C.teal})`, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16 }}>
      <div style={{ width: 56, height: 56, border: `4px solid ${C.gold}`, borderTopColor: "transparent", borderRadius: "50%", animation: "spin 1s linear infinite" }} />
      <div style={{ color: C.white, fontWeight: 700, letterSpacing: 2 }}>YAALI GROUP</div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  const BIZ_TABS = nav === "inmobiliaria" ? ["clientes", "servicios", "inventario"] : ["clientes", "servicios"];

  return (
    <div style={{ fontFamily: "'Segoe UI', system-ui, sans-serif", background: C.offWht, minHeight: "100vh", maxWidth: 480, margin: "0 auto", paddingBottom: 80 }}>
      {/* HEADER */}
      <div style={{ background: `linear-gradient(135deg,${C.tealDk},${C.teal})`, padding: "16px 20px 14px", position: "sticky", top: 0, zIndex: 100 }}>
        {nav === "dashboard" ? (
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: "50%", border: `2px solid ${C.gold}`, background: C.white + "20", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🏡</div>
            <div>
              <div style={{ color: C.white, fontWeight: 900, fontSize: 17, lineHeight: 1.1 }}>Yaali Group</div>
              <div style={{ color: C.gold, fontSize: 10, fontWeight: 600, letterSpacing: 1 }}>ENCUENTRA TU LUGAR</div>
            </div>
          </div>
        ) : (
          <div>
            <button onClick={() => setNav("dashboard")} style={{ background: "none", border: "none", color: C.gold, fontWeight: 700, fontSize: 12, cursor: "pointer", padding: 0, marginBottom: 6, display: "flex", alignItems: "center", gap: 4 }}>← Inicio</button>
            <div style={{ color: C.white, fontWeight: 900, fontSize: 17 }}>{BIZ_META[nav].icon} {BIZ_META[nav].label}</div>
            {/* Tabs */}
            <div style={{ display: "flex", gap: 6, marginTop: 10 }}>
              {BIZ_TABS.map(t => (
                <button key={t} onClick={() => setTab(t)} style={{ border: "none", borderRadius: 20, padding: "5px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer", background: tab === t ? C.gold : C.white + "20", color: tab === t ? C.tealDk : C.white, textTransform: "capitalize" }}>
                  {t === "inventario" ? "🏠 Inventario" : t === "clientes" ? "👥 Clientes" : "📦 Servicios"}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* CONTENT */}
      <div style={{ padding: "16px 16px 0" }}>
        {nav === "dashboard" && <Dashboard data={data} />}
        {nav !== "dashboard" && tab === "clientes" && (
          <ClientesModule biz={nav} clientes={data.clientes[nav] || []} onChange={(list) => updateClientes(nav, list)} toast={toast} />
        )}
        {nav !== "dashboard" && tab === "servicios" && (
          <ServiciosModule biz={nav} servicios={data.servicios[nav] || []} onChange={(list) => updateServicios(nav, list)} toast={toast} />
        )}
        {nav === "inmobiliaria" && tab === "inventario" && (
          <InventarioModule inventario={data.inventario} onChange={updateInventario} toast={toast} />
        )}
      </div>

      {/* BOTTOM NAV */}
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: C.white, borderTop: `1px solid ${C.gray100}`, display: "flex", zIndex: 99 }}>
        {[
          { key: "dashboard", label: "Inicio", icon: "🏠" },
          { key: "inmobiliaria", label: "Inmobiliaria", icon: "🏡" },
          { key: "studio", label: "Studio", icon: "🎨" },
          { key: "hyg", label: "HYG", icon: "📋" },
        ].map(item => (
          <button key={item.key} onClick={() => { setNav(item.key); setTab("clientes"); }} style={{ flex: 1, border: "none", background: "none", padding: "10px 4px 8px", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
            <div style={{ fontSize: nav === item.key ? 22 : 18, transition: "font-size .15s" }}>{item.icon}</div>
            <div style={{ fontSize: 10, fontWeight: 700, color: nav === item.key ? C.teal : C.gray400 }}>{item.label}</div>
            {nav === item.key && <div style={{ width: 20, height: 3, borderRadius: 2, background: C.teal }} />}
          </button>
        ))}
      </div>

      <Toast msg={toastMsg} />
    </div>
  );
}
